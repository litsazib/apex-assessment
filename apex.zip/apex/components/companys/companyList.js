import { DataTable } from 'mantine-datatable';
import { useState, useEffect, Fragment } from 'react';
import sortBy from 'lodash/sortBy';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment';
import { list } from '@/store/slices/companySlice';
import { showAlert } from '@/utils';
import Select from 'react-select';

const CompanyList = () => {
  const dispatch = useDispatch();
  const { isLoading, data } = useSelector((state) => state.companyList);
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [status,setSelectStatus] = useState({ value: '1', label: 'In-Progress' })
  const PAGE_SIZES = [5];
  const [pageSize, setPageSize] = useState(PAGE_SIZES[0]);
  const [initialRecords, setInitialRecords] = useState(sortBy(items, 'id'));
  const [records, setRecords] = useState(initialRecords);
  const [search, setSearch] = useState('');
  const [sortStatus, setSortStatus] = useState({
    columnAccessor: 'id',
    direction: 'desc',
  });

  const statusOptions = [
    { value: '1', label: 'In-Progress' },
    { value: '0', label: 'Progress' },
  ];
  useEffect(() => {
    const from = (page - 1) * pageSize;
    const to = from + pageSize;
    setRecords([...initialRecords.slice(from, to)]);
  }, [page, status, initialRecords]);

  useEffect(() => {
    const data2 = sortBy(initialRecords, sortStatus.columnAccessor);
    setRecords(sortStatus.direction === 'desc' ? data2.reverse() : data2);
  }, [sortStatus, items,status]);

  const ListOfCompany = async () => {
    try {
      if(search.length) {
        setPage(1)
        setPageSize(5)
      }
      const result = await dispatch(list({page,search,status })).unwrap();
      const {total,data} = result?.data?.company_list || {}
      if (result.status === 200) {
        setTotalCount(total)
        setItems(data);
        setInitialRecords(data);
      } else {
        showAlert(result?.message, 'error');
      }
    } catch (error) {
      showAlert(error.message, 'error');
    }
  };


  useEffect(() => {
    setInitialRecords(() => {
      return items?.filter((item, id) => {
        return item.company_name?.toLowerCase().includes(search.toLowerCase());
      });
    });
  }, [search,page,status]);

  useEffect(() => {
    ListOfCompany();
  }, [page,search,status]);

  return (
    <div className="panel border-white-light px-0 dark:border-[#1b2e4b]">
      <div className="invoice-table">
        <div className="mb-4.5 flex flex-col gap-5 px-5 md:flex-row md:items-center">
          <div className="flex items-center gap-2">
            <h1 className='text-lg font-semibold dark:text-white-light'>Company List</h1>
          </div>
          <div className="ltr:ml-auto rtl:mr-auto flex items-center gap-2 z-10">
            <label>Status</label>
          <Select
            className='capitalize'
            name="status"
            id="status"
            placeholder="Select Status"
            options={statusOptions}
            isSearchable={true}
            onChange={(e) => {
              setSelectStatus(e.value)
            }}
          />
            <input
              type="text"
              className="form-input w-auto"
              placeholder="Filter By Company name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        {!isLoading ? (
          <div className="datatables pagination-padding">
            <DataTable
              className="table-hover whitespace-nowrap"
              records={records}
              columns={[
                {
                  accessor: 'company_name',
                  title: 'Company Name',
                  sortable: true,
                  render: ({ company_name }) => (
                    <div className='capitalize'>
                      {company_name}
                    </div>
                  ),
                },
                {
                  accessor: 'company_phone',
                  title: 'Company Phone',
                  sortable: true,
                  render: ({ company_phone }) => (
                    <div>
                      {company_phone}
                    </div>
                  ),
                },
                {
                  accessor: 'address1',
                  title: 'Address 1',
                  sortable: true,
                  render: ({ address1 }) => (
                    <div className='capitalize'>
                      {address1}
                    </div>
                  ),
                },
                {
                  accessor: 'city',
                  title: 'City',
                  sortable: true,
                  render: ({ city }) => (
                    <div className='capitalize'>
                      {city}
                    </div>
                  ),
                },
                {
                  accessor: 'company_status',
                  title: 'Status',
                  sortable: true,
                  render: ({ company_status }) => (
                    <span 
                    className=
                    {`badge capitalize ${ 
                      company_status === '1' ? 'bg-success': 
                      company_status === '0' ? 'bg-danger':
                    'bg-primary'
                    }`
                    }>
                      {company_status === '1'? 'In-Progress' :'Non-Progress'}
                    </span>
                  ),
                },
                {
                  accessor: 'created_at',
                  sortable: true,
                  render: ({ created_at } = undefined || {}) => (
                    <div>{moment(created_at).format('LL')}</div>
                  ),
                },
              ]}
              highlightOnHover
              totalRecords={totalCount}
              recordsPerPage={pageSize}
              page={page}
              onPageChange={(p) => {
                setSearch('')
                setPage(p)
              }}
              recordsPerPageOptions={PAGE_SIZES}
              onRecordsPerPageChange={setPageSize}
              sortStatus={sortStatus}
              onSortStatusChange={setSortStatus}
              paginationText={({ from, to, totalRecords }) =>
                `Showing  ${from} to ${to} of ${totalRecords} entries`
              }
            />
          </div>
          ) : (
          <>
            <span className="m-auto mb-10 flex h-14 w-14 animate-spin rounded-full border-8 border-[#f1f2f3] border-l-primary align-middle"></span>
          </>
        )}
      </div>
    </div>
  );
};

export default CompanyList;
