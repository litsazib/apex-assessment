const BASE_URL = 'http://139.59.35.127/'

export const URL = {
    getAllCompany:BASE_URL+'production/propsoft-api/public/api/get-all-companys',

}