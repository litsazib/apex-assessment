import FrontLayout from '@/components/layouts/FrontLayout';
import CompanyList from '@/components/companys/companyList';

const Index = () => {
  return (
    <FrontLayout>
      <CompanyList/>
    </FrontLayout>
  );
};

export default Index;
