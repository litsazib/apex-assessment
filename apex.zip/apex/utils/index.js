import Swal from 'sweetalert2';
export const showAlert = (title, type) => {
  const toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
  });
  return toast.fire({
    icon: type,
    title,
    padding: '10px 20px',
  });
};
