import axios from "axios";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {URL} from "@/constants/endpoint"

export const list = createAsyncThunk(
  "/company/list",
  async (payload, { rejectWithValue }) => {
    const {page,search,status} = payload
    const searchParam = search ? `&company_name=${search}` : '';
    const statusParam = status ? `?company_status=${status}` : '';
    try {
      return axios.get(URL.getAllCompany+`?page=${page}${statusParam}${searchParam}`).then((res) => {
        return res;
      });
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

export const companySlice = createSlice({
  name: "company",
  initialState: {
    data: {},
    isLoading: false,
    error: {},
  },
  reducers: {
    setLoadingStatus: (state, action) => {
      state.isLoading = action.payload;
    }
  },
  extraReducers: (builder) => {  
    // List 
    builder.addCase(list.pending, (state, action) => {
      state.isLoading = true;
    });
    builder.addCase(list.fulfilled, (state, action) => {
      state.data = action.payload?.data?.company_list
      state.isLoading = false;
      state.error = {};
      
    });
    builder.addCase(list.rejected, (state, action) => {
      state.isLoading = false;
      state.error = action.payload;
    });
  },
});

export const { setLoadingStatus } = companySlice.actions;

export default companySlice.reducer;
